# Deadwood-Game
We will create the Deadwood game in Java https://cheapass.com//wp-content/uploads/2016/07/Deadwood-Free-Edition-Rules.pdf
