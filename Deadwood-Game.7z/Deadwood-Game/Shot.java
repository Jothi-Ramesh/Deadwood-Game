public class Shot{
    int shotNum;
    int budget;
    String roleNames[][];
    int roleDiff[][];
    String name;
    int numRoles;
    int filledRoles[][];
    public Shot(String name, int numRoles, int budget, int shotNum, String roleNames[][], int roleDiff[][]) {

    }
}
